package cn.enjoyedu.nettybasic.serializable.protobuf;

/**
 * @author Mark老师   享学课堂 https://enjoy.ke.qq.com
 * 类说明：实体类
 */
public class Person {
    String name;
    int id;
    String email;
}
