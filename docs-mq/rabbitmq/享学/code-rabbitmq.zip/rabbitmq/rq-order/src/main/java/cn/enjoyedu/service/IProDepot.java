package cn.enjoyedu.service;

/**

 *类说明：
 */
public interface IProDepot {

    public void processDepot(String goodsId, int amount);

}
