package cn.enjoyedu.rpc;


import cn.enjoyedu.vo.GoodTransferVo;

/**

 *类说明：
 */
public interface DepotService {
    public void changeDepot(GoodTransferVo goodTransferVo);
}
