package cn.enjoyedu.vo;

/**

 *类说明：
 */
public class GoodDepotStat {
    private String goodsId;
    private boolean isEmpty;

    public String getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(String goodsId) {
        this.goodsId = goodsId;
    }

    public boolean isEmpty() {
        return isEmpty;
    }

    public void setEmpty(boolean empty) {
        isEmpty = empty;
    }
}
