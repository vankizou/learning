package cn.enjoyedu.rpc;

/**

 *类说明：
 */
public class RpcConst {

    public static final String SUCCESS = "success";
    public static final String FAILURE = "failure";
    public static final String EXCEPTION = "exception";

}
